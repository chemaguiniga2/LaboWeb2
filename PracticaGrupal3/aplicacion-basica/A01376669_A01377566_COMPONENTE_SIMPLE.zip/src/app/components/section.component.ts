import { Component } from '@angular/core';
    @Component({
        selector: 'app-section',
        templateUrl: 'section.component.html'
    })
export class SectionComponent {
    artista:string = "David Gilmour";
    fecha:string = "Septiembre 2015";
}