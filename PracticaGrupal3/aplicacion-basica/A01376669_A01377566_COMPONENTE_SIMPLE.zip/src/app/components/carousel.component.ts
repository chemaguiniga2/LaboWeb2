import { Component } from '@angular/core';
    @Component({
        selector: 'app-carousel',
        templateUrl: 'carousel.component.html'
    })
export class CarouselComponent {
    artista:string = "David Gilmour";
    fecha:string = "Septiembre 2015";
}